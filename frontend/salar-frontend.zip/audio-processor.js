/**
 * SALAR Live Audio Worklet Processor
 * - Captures mic audio, resamples to 16kHz PCM16, sends to main thread
 * - Receives 24kHz PCM16 playback audio from main thread, resamples to hardware rate
 */
class SalarAudioProcessor extends AudioWorkletProcessor {
  constructor() {
    super()
    this._captureBuffer = new Float32Array(1600) // ~100ms at 16kHz
    this._captureWriteIdx = 0
    this._targetSampleRate = 16000
    this._playbackQueue = []
    this._playbackReadIdx = 0
    this._hardwareSampleRate = sampleRate // e.g. 44100 or 48000
    this._playbackResampleBuffer = new Float32Array(0)
    this._resampleReadIdx = 0
    this._playing = false
    this._gainNode = null

    this.port.onmessage = (e) => {
      const msg = e.data
      if (msg.type === 'playback') {
        // msg.samples: Float32Array or Int16Array at 24kHz
        let float32
        if (msg.samples instanceof Int16Array) {
          float32 = new Float32Array(msg.samples.length)
          for (let i = 0; i < msg.samples.length; i++) {
            float32[i] = msg.samples[i] / 32768.0
          }
        } else {
          float32 = new Float32Array(msg.samples)
        }
        this._playbackQueue.push(float32)
        this._playing = true
      } else if (msg.type === 'stop') {
        this._playbackQueue = []
        this._playbackResampleBuffer = new Float32Array(0)
        this._resampleReadIdx = 0
        this._playing = false
      }
    }
  }

  process(inputs, outputs, parameters) {
    const input = inputs[0]
    const output = outputs[0]

    if (input && input[0]) {
      const inputChannel = input[0]
      this._resampleAndCapture(inputChannel)
    }

    // Fill output from playback queue
    const outChannel = output[0]
    if (this._playing && this._playbackQueue.length > 0) {
      let written = 0
      while (written < outChannel.length && this._playbackQueue.length > 0) {
        if (this._resampleReadIdx < this._playbackResampleBuffer.length) {
          const avail = this._playbackResampleBuffer.length - this._resampleReadIdx
          const needed = outChannel.length - written
          const take = Math.min(avail, needed)
          outChannel.set(this._playbackResampleBuffer.subarray(this._resampleReadIdx, this._resampleReadIdx + take), written)
          this._resampleReadIdx += take
          written += take
        } else {
          const next = this._playbackQueue.shift()
          if (next && next.length > 0) {
            this._playbackResampleBuffer = this._upsample(next, 24000, this._hardwareSampleRate)
            this._resampleReadIdx = 0
          } else {
            break
          }
        }
      }
      if (written < outChannel.length) {
        for (let i = written; i < outChannel.length; i++) outChannel[i] = 0
      }
    } else {
      for (let i = 0; i < outChannel.length; i++) outChannel[i] = 0
    }

    return true
  }

  _resampleAndCapture(inputChannel) {
    const inputRate = this._hardwareSampleRate
    const outputRate = this._targetSampleRate
    const ratio = inputRate / outputRate

    const needed = Math.floor(inputChannel.length / ratio)
    for (let i = 0; i < needed; i++) {
      const srcIdx = i * ratio
      const idx0 = Math.floor(srcIdx)
      const idx1 = Math.min(idx0 + 1, inputChannel.length - 1)
      const frac = srcIdx - idx0
      const sample = inputChannel[idx0] * (1 - frac) + inputChannel[idx1] * frac

      const int16 = Math.max(-32768, Math.min(32767, Math.round(sample * 32768)))
      this._captureBuffer[this._captureWriteIdx] = int16 / 32768.0
      this._captureWriteIdx++

      if (this._captureWriteIdx >= 1600) {
        const pcm16 = new Int16Array(1600)
        for (let j = 0; j < 1600; j++) {
          pcm16[j] = Math.max(-32768, Math.min(32767, Math.round(this._captureBuffer[j] * 32768)))
        }
        this.port.postMessage({ type: 'capture', samples: pcm16 })
        this._captureWriteIdx = 0
      }
    }
  }

  _upsample(input, inputRate, outputRate) {
    if (inputRate === outputRate) return input
    const ratio = outputRate / inputRate
    const outLen = Math.ceil(input.length * ratio)
    const out = new Float32Array(outLen)
    for (let i = 0; i < outLen; i++) {
      const srcIdx = i / ratio
      const idx0 = Math.floor(srcIdx)
      const idx1 = Math.min(idx0 + 1, input.length - 1)
      const frac = srcIdx - idx0
      out[i] = input[idx0] * (1 - frac) + input[idx1] * frac
    }
    return out
  }
}

registerProcessor('salar-audio', SalarAudioProcessor)
